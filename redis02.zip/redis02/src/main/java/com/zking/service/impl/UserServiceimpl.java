package com.zking.service.impl;

import com.zking.mapper.Tb_UserMapper;
import com.zking.pojo.Tb_User;
import com.zking.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("UserServiceimpl")
public class UserServiceimpl implements IUserService {

    @Autowired
    private Tb_UserMapper tum;

    @Override
    public List<Tb_User> findUser(Tb_User user) {
        return tum.findUser(user);
    }

    @Override
    public int AddUser(Tb_User user) {
        return tum.AddUser(user);
    }

    @Override
    public int editUser(Tb_User user) {
        return tum.editUser(user);
    }

    @Override
    public int deleteUser(Tb_User user) {
        return tum.deleteUser(user);
    }
}
