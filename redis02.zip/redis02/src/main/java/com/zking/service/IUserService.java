package com.zking.service;

import com.zking.pojo.Tb_User;

import java.util.List;

public interface IUserService {

    public List<Tb_User> findUser(Tb_User  user);


    public  int AddUser(Tb_User user);

    public int  editUser(Tb_User  user);


    public  int deleteUser(Tb_User user);
}
