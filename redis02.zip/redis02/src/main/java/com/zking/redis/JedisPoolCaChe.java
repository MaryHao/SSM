package com.zking.redis;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;

public class JedisPoolCaChe {


    private redis.clients.jedis.JedisPool jedisPool;


    public redis.clients.jedis.JedisPool getJedisPool() {
        return jedisPool;
    }

    public void setJedisPool(redis.clients.jedis.JedisPool jedisPool) {
        this.jedisPool = jedisPool;
    }


    public <T> void setJedisKeyString(String key, T value) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        if (value != null) {
            String outStr = objectMapper.writeValueAsString(value);
            jedisPool.getResource().set(key, outStr);
        }

    }


    public String getJedisKeyString(String key) {
        return jedisPool.getResource().get(key);
    }





    public <T> List<T> getJedisKeyList(String key, Class<T> valueType) throws Exception {
        String readStr = jedisPool.getResource().get(key);
        ObjectMapper objectMapper = new ObjectMapper();
        JavaType javaType = objectMapper.getTypeFactory().constructParametricType(ArrayList.class, valueType);
        return objectMapper.readValue(readStr, javaType);
    }





    public <T> T getJedisKeyObject(String key, Class<T> value) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        String outStr = objectMapper.writeValueAsString(value);
        return objectMapper.readValue(outStr, value);
    }
}
