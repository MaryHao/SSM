package com.zking.controller;

import com.zking.pojo.Tb_User;
import com.zking.redis.JedisPoolCaChe;
import com.zking.service.IUserService;
import com.zking.service.impl.UserServiceimpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class UserController {


    String out = "n";
    @Autowired
    private IUserService ius = new UserServiceimpl();
    JedisPoolCaChe jedisPoolCaChe = new JedisPoolCaChe();
    private final String key = "com.zking.redis.JedisPoolCaChe";

    @ResponseBody
    @RequestMapping("findUsers")
    public String findUser(Tb_User user) {
        return jedisPoolCaChe.getJedisKeyString(key);
    }

    @ResponseBody
    @RequestMapping("AddUser")
    public String AddUser(Tb_User user) throws Exception {
        if (ius.AddUser(user) > 0) {
            List<Tb_User> jedisKeyList = jedisPoolCaChe.getJedisKeyList(key, Tb_User.class);
            jedisKeyList.add(user);
            out = "y";
        }
        return out;
    }

    @ResponseBody
    @RequestMapping("editUser")
    public String editUser(Tb_User user) throws Exception {
        if (ius.editUser(user) > 0) {
            List<Tb_User> jedisKeyList = jedisPoolCaChe.getJedisKeyList(key, Tb_User.class);
            for (Tb_User tbUser : jedisKeyList) {
                if (tbUser.getUser_id().equals(user.getUser_id())) {
                    tbUser.setUser_name(user.getUser_name());
                    tbUser.setUser_pwd(user.getUser_pwd());
                    out = "y";
                    break;
                }
            }

        }
        return out;

    }

    @ResponseBody
    @RequestMapping("deleteUser")
    public String deleteUser(Tb_User user) throws Exception {
        if (ius.deleteUser(user) > 0) {
            List<Tb_User> jedisKeyList = jedisPoolCaChe.getJedisKeyList(key, Tb_User.class);
            for (Tb_User tbUser : jedisKeyList) {
                if (tbUser.getUser_id().equals(user.getUser_id())) {
                    jedisKeyList.remove(tbUser);
                    out = "y";
                    break;
                }
            }

        }
        return out;

    }

}
